<?php

$METRI_TOKEN = "https://api.telegram.org/bot6582792883:AAFQNePVk6r0QP-dPwc0fFXaLJJt7RpS3cws";

$chat_id = "-4050040892";

// $reload = '3';

?>